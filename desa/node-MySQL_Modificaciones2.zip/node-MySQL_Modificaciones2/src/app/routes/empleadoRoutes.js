const express = require('express');
const router = express.Router();
const dbConnection = require('../../config/dbConnection');
const connection = dbConnection();

// ... Definir tus rutas aquí
router.get('/', (req, res) =>{  //FUNCIONA BIEN
    connection.query('CALL ObtenerTodosLosEmpleados()', (err,result) => {
        res.render('news/empleado',{
            Empleado: result[0] 
        });
    });        
}); 
router.delete('/:id', (req, res) => {
    const idEmpleado = req.params.id;
    connection.query('DELETE FROM Empleado WHERE ID_usuario = ?', [idEmpleado], (err, result) => {
        if (err) throw err;
        res.send('Empleado eliminado correctamente');
    });
});
router.post('/', (req, res) => {  //FUNCIONA BIEN
    const { Id_usuario, Usuario } = req.body;
    connection.query('INSERT INTO Empleado SET ?', {  // Corrige aquí, agrega un espacio después de SET
        Id_usuario,
        Usuario
    }, (err, result) => {
        if (err) throw err;  // Manejo básico de errores, puedes personalizar según tus necesidades
        res.redirect('/');
    });
});
router.put('/:id', (req, res) => {
    const idEmpleado = req.params.id;
    const { Usuario } = req.body;
    connection.query('UPDATE Empleado SET Usuario=? WHERE Id_empleado=?',
        [Usuario, idEmpleado],
        (err, result) => {
            if (err) throw err;
            res.send('Empleado actualizado correctamente');
        });
});

module.exports = router;
