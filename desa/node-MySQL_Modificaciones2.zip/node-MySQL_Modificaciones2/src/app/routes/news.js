const express = require('express');
const router = express.Router();
const viajeRoutes = require('./viajeRoutes');
const pasajeroRoutes = require('./pasajeroRoutes');
const empleadoRoutes = require('./empleadoRoutes');
const turnoTransporteRoutes = require('./turnoTransporteRoutes');

router.use('/', viajeRoutes);
router.use('/pasajero', pasajeroRoutes);
router.use('/empleado', empleadoRoutes);
router.use('/turnotransporte', turnoTransporteRoutes);

// ... Otras rutas específicas de news si es necesario

module.exports = router;



