const express = require('express');
const router = express.Router();
const dbConnection = require('../../config/dbConnection');
const connection = dbConnection();

// ... Definir tus rutas aquí
router.get('/', (req, res) => {  //FUNCIONA BIEN
    connection.query('CALL ObtenerTodosLosPasajeros()', (err, result) => {
        if (err) throw err;  // Manejo básico de errores, puedes personalizar según tus necesidades
        res.render('news/pasajero', {
            Pasajero: result[0]  // Los resultados del procedimiento almacenado pueden estar en result[0]
        });
    });
});

router.post('/', (req, res) => {  //FUNCIONA BIEN
    const { DNI, Nombre, Apellido } = req.body;
    connection.query('INSERT INTO Pasajero SET ?', {
        DNI,
        Nombre,
        Apellido
    }, (err, result) => {
        if (err) throw err;  // Manejo básico de errores, puedes personalizar según tus necesidades
        res.redirect('/');
    });
});
router.delete('/:id', (req, res) => {
    const idPasajero = req.params.id;
    connection.query('DELETE FROM Pasajero WHERE DNI = ?', [idPasajero], (err, result) => {
        if (err) throw err;
        res.send('Pasajero eliminado correctamente');
    });
});

 
router.put('/:id', (req, res) => {
    const idPasajero = req.params.id;
    const { Nombre, Apellido } = req.body;
    connection.query('UPDATE Pasajero SET Nombre=?, Apellido=? WHERE DNI=?',
        [Nombre, Apellido, idPasajero],
        (err, result) => {
            if (err) throw err;
            res.send('Pasajero actualizado correctamente');
        });
});

module.exports = router;
