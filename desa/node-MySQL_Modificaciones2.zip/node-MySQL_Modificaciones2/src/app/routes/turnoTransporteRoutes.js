const express = require('express');
const router = express.Router();
const dbConnection = require('../../config/dbConnection');
const connection = dbConnection();

// ... Definir tus rutas aquí
router.get('/', (req, res) =>{  //FUNCIONA BIEN
    connection.query('CALL ObtenerTodosLosTurnoTransporte()', (err,result) => {
        res.render('news/turnotransporte',{
            TurnoTransporte: result[0] 
        });
    });        
});
router.delete('/:id', (req, res) => {
    const idTurnoTransporte = req.params.id;
    connection.query('DELETE FROM TurnoTransporte WHERE Id_turno = ?', [idTurnoTransporte], (err, result) => {
        if (err) throw err;
        res.send('Turno de transporte eliminado correctamente');
    });
});
router.post('/', (req, res) => {   //FUNCIONA BIEN
    const { Id_turno, Origen, Destino, Hora_salida, Turno, Ruta } = req.body;
    connection.query('INSERT INTO TurnoTransporte SET ?', {  // Corrige aquí, agrega un espacio después de SET
        Id_turno, 
        Origen, 
        Destino, 
        Hora_salida, 
        Turno, 
        Ruta
    }, (err, result) => {
        if (err) throw err;  // Manejo básico de errores, puedes personalizar según tus necesidades
        res.redirect('/');
    });
}); 
router.put('/:id', (req, res) => {
    const idTurnoTransporte = req.params.id;
    const { Origen, Destino, Hora_salida, Turno, Ruta } = req.body;
    connection.query('UPDATE TurnoTransporte SET Origen=?, Destino=?, Hora_salida=?, Turno=?, Ruta=? WHERE Id_turno=?',
        [Origen, Destino, Hora_salida, Turno, Ruta, idTurnoTransporte],
        (err, result) => {
            if (err) throw err;
            res.send('Turno de transporte actualizado correctamente');
        });
});  

module.exports = router;
