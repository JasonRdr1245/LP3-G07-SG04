const express = require('express');
const router = express.Router();
const dbConnection = require('../../config/dbConnection');
const connection = dbConnection();

// ... Definir tus rutas aquí
router.get('/', (req, res) =>{ //FUNCIONA BIEN
    connection.query('CALL ObtenerTodosLosViajes()', (err,result) => {
        res.render('news/news',{
            Viaje: result[0] 
        });
    });        
}); 
router.post('/', (req, res) => {  //FUNCIONA BIEN
    const { Id_viaje, Id_turno, Id_DNI, ID_empleado, Fecha_emision, Fecha_viaje, Total_Pago, Numero_asiento } = req.body;
    connection.query('INSERT INTO Viaje SET ?', {  // Corrige aquí, agrega un espacio después de SET
        Id_viaje,
        Id_turno,
        Id_DNI,
        ID_empleado,
        Fecha_emision,
        Fecha_viaje,
        Total_Pago,
        Numero_asiento
    }, (err, result) => {
        if (err) throw err;  // Manejo básico de errores, puedes personalizar según tus necesidades
        res.redirect('/');
    });
});
router.delete('/:id', (req, res) => {  //FUNCIONA BIEN
    const idViaje = req.params.id;
    connection.query('DELETE FROM Viaje WHERE Id_viaje = ?', [idViaje], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error al eliminar viaje');
        }
        res.send('Viaje eliminado correctamente');
    });
});

router.put('/:id', (req, res) => {
    const idViaje = req.params.id;
    const { Id_turno, Id_DNI, ID_empleado, Fecha_emision, Fecha_viaje, Total_Pago, Numero_asiento } = req.body;
    connection.query('UPDATE Viaje SET Id_turno=?, Id_DNI=?, ID_empleado=?, Fecha_emision=?, Fecha_viaje=?, Total_Pago=?, Numero_asiento=? WHERE Id_viaje=?',
    [Id_turno, Id_DNI, ID_empleado, Fecha_emision, Fecha_viaje, Total_Pago, Numero_asiento, idViaje], (err, result) => {
        if (err) throw err;
        res.send('Viaje actualizado correctamente');
    });
}); 

module.exports = router;
