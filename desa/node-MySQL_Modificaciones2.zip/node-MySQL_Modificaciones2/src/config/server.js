// server.js
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const newsRoutes = require('../app/routes/news');
const app = express();

// Configuración de vistas y middleware
// settings
app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../app/views'));
// middlewares
app.use(bodyParser.urlencoded({extended: false}));
app.use(methodOverride('_method')); 
app.use(express.static(path.join(__dirname, '../static')));
// Agregar las rutas principales
app.use('/', newsRoutes);

module.exports = app;
