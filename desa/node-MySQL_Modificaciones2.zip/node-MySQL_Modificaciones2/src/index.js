// index.js
const app = require('./config/server'); // Cambié la ruta para que coincida con la ubicación real
const newsRoutes = require('./app/routes/news');

// Configuración de rutas
app.use('/', newsRoutes);

// Inicio del servidor
app.listen(app.get('port'), () => {
    console.log('Server on port ', app.get('port'));
});
