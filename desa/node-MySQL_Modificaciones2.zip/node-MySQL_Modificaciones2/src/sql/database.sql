create database TDCEB;
use TDCEB;

CREATE TABLE Pasajero (
    DNI VARCHAR(8) NOT NULL,
    Nombre VARCHAR(30),
    Apellido VARCHAR(30),
    PRIMARY KEY (DNI),
    CHECK (DNI REGEXP '^[0-9]{8}$')
);


create table Empleado(
	ID_usuario varchar(4) primary key,
	Usuario varchar(20));

create table TurnoTransporte(
	Id_turno varchar(4) primary key,
	Origen varchar(20),
	Destino varchar(20),
	Hora_salida time,
	Turno varchar (10),
	Ruta varchar(50));

CREATE TABLE Viaje (
    Id_viaje VARCHAR(4),
    Id_turno VARCHAR(4),
    Id_DNI VARCHAR(8),
    ID_empleado VARCHAR(4),
    Fecha_emision DATETIME CHECK (Fecha_emision >= '2023-01-01' AND Fecha_emision <= '2023-12-31'),
    Fecha_viaje DATE,
    Total_Pago DECIMAL(5, 2) DEFAULT 0.00,
    Numero_asiento VARCHAR(2) CHECK (Numero_asiento NOT LIKE '%[^0-9]%'),
    FOREIGN KEY (Id_turno) REFERENCES TurnoTransporte(Id_turno),
    FOREIGN KEY (Id_DNI) REFERENCES Pasajero(DNI),
    FOREIGN KEY (ID_empleado) REFERENCES Empleado(Id_usuario)
);
CREATE TABLE Auditoria (
    ID_audit INT AUTO_INCREMENT PRIMARY KEY,
    accion VARCHAR(10),
    tabla_afectada VARCHAR(20),
    fecha DATETIME
);


insert into Pasajero(DNI,Nombre,Apellido) values 
	('98765432','Franco','Paredes'),
	('87654321','Marcelo','Nunez'),
	('76543210','Josue','Cornejo'),
	('65432109','Daniel','Del Carpio'),
	('54321098','Salvador','Zamora'),
	('43210987','Salvador','Paredes'),
	('32109876','Franco','Zamora'),
	('21098765','Cynthia','Portilla'),
	('10987654','Angela','Silva');
	
insert into Empleado(ID_usuario,Usuario) values ('0001','Zamora');
insert into TurnoTransporte(Id_turno,Origen,Destino,Hora_salida,Turno,Ruta) values 
	('1001', 'Lima', 'Cusco', '09:00:00', 'Dia', 'Avenida Ficción 123, Ciudad Imaginaria'),
    ('1002', 'Lima', 'Trujillo', '19:15:00', 'Noche', 'Calle Irreal 456, Ciudad de los Sueños'),
    ('1003', 'Lima', 'Piura', '10:30:00', 'Dia', 'Bulevar de Fantasía 789, Pueblo de Ensueño'),
    ('1004', 'Lima', 'Iquitos', '19:45:00', 'Noche', 'Camino de los Sueños 567, Villa Ilusión'),
    ('1005', 'Lima', 'Arequipa', '20:00:00', 'Noche', 'Carrera de Ensueño 890, Ciudad Soñada');
	
insert into Viaje(Id_viaje,Id_turno,Id_DNI,ID_empleado, Fecha_emision,Fecha_viaje,Total_Pago,Numero_asiento) values 
	('2001', '1001', '98765432', '0001', '2023-11-19 14:45:00', '2023-12-15', 120.50, '01'),
    ('2002', '1002', '87654321', '0001', '2023-11-20 15:00:00', '2023-12-20', 95.75, '02'),
    ('2003', '1003', '76543210', '0001', '2023-11-21 16:15:00', '2023-12-25', 110.25, '08'),
    ('2004', '1004', '65432109', '0001', '2023-11-22 17:30:00', '2023-12-30', 80.00, '03'),
    ('2005', '1005', '54321098', '0001', '2023-11-23 18:45:00', '2024-01-05', 150.30, '05'),
    ('2006', '1001', '43210987', '0001', '2023-11-24 20:00:00', '2024-01-10', 115.80, '06'),
    ('2007', '1002', '32109876', '0001', '2023-11-25 21:15:00', '2024-01-15', 90.25, '04'),
    ('2008', '1003', '21098765', '0001', '2023-11-26 22:30:00', '2024-01-20', 105.50, '07'),
    ('2009', '1004', '10987654', '0001', '2023-11-27 23:45:00', '2024-01-25', 130.75, '09');

DELIMITER //
CREATE PROCEDURE ObtenerTodosLosPasajeros()
BEGIN
    SELECT * FROM Pasajero;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ObtenerTodosLosEmpleados()
BEGIN
    SELECT * FROM Empleado;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ObtenerTodosLosViajes()
BEGIN
    SELECT * FROM Viaje;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ObtenerTodosLosTurnoTransporte()
BEGIN
    SELECT * FROM TurnoTransporte;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ObtenerViajesPorTurno(IN p_Id_turno varchar(4))
BEGIN
    SELECT * FROM Viaje WHERE Id_turno = p_Id_turno;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ObtenerTotalPagoPorPasajero(IN p_Id_DNI varchar(8), OUT p_TotalPago DECIMAL(5,2))
BEGIN
    SELECT SUM(Total_Pago) INTO p_TotalPago FROM Viaje WHERE Id_DNI = p_Id_DNI;

    -- Si no hay registros para el pasajero, establece el total en 0.
    IF p_TotalPago IS NULL THEN
        SET p_TotalPago = 0.00;
    END IF;
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER BeforeInsertPasajero
BEFORE INSERT ON Pasajero
FOR EACH ROW
BEGIN
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('INSERT', 'Pasajero', NOW());
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER BeforeUpdatePasajero
BEFORE UPDATE ON Pasajero
FOR EACH ROW
BEGIN
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('UPDATE', 'Pasajero', NOW());
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER BeforeDeletePasajero
BEFORE DELETE ON Pasajero
FOR EACH ROW
BEGIN    
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('DELETE', 'Pasajero', NOW());
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER AfterInsertViaje
AFTER INSERT ON Viaje
FOR EACH ROW
BEGIN   
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('INSERT', 'Viaje', NOW());
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER AfterUpdateViaje
AFTER UPDATE ON Viaje
FOR EACH ROW
BEGIN    
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('UPDATE', 'Viaje', NOW());
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER AfterDeleteViaje
AFTER DELETE ON Viaje
FOR EACH ROW
BEGIN    
    INSERT INTO Auditoria (accion, tabla_afectada, fecha) VALUES ('DELETE', 'Viaje', NOW());
END //
DELIMITER ;

select * from Pasajero;
select * from Empleado;
select * from TurnoTransporte;
select * from Viaje;


SELECT COUNT(*) AS CantidadRegistros FROM Viaje WHERE MONTH(Fecha_emision) = MONTH(NOW()) AND YEAR(Fecha_emision) = YEAR(NOW());

SELECT SUM(Total_Pago) AS TotalGanancias FROM Viaje;

SELECT V.Id_viaje, V.Fecha_emision, SUM(V.Total_Pago) AS TotalViaje
FROM Viaje V
WHERE V.Id_viaje = '2001'
GROUP BY V.Id_viaje, V.Fecha_emision;

SELECT P.DNI, P.Nombre, P.Apellido
FROM Pasajero P
JOIN Viaje V ON P.DNI = V.Id_DNI
JOIN Empleado E ON V.ID_empleado = E.ID_usuario
WHERE E.Usuario = 'Zamora'; 

SELECT E.Usuario AS Empleado, COUNT(V.Id_viaje) AS TotalViajes
FROM Empleado E
JOIN Viaje V ON E.ID_usuario = V.ID_empleado
GROUP BY E.Usuario
ORDER BY TotalViajes DESC;

SELECT Destino, COUNT(*) AS TotalViajes
FROM TurnoTransporte
GROUP BY Destino
ORDER BY TotalViajes DESC
LIMIT 1;

SELECT MONTH(Fecha_viaje) AS Mes, COUNT(*) AS TotalViajes
FROM Viaje
GROUP BY Mes
ORDER BY TotalViajes DESC
LIMIT 1;

SELECT V.Id_DNI AS DNI_Pasajero, P.Nombre, P.Apellido, SUM(V.Total_Pago) AS TotalPagado
FROM Viaje V
JOIN Pasajero P ON V.Id_DNI = P.DNI
GROUP BY V.Id_DNI, P.Nombre, P.Apellido;